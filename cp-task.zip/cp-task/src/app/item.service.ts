import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Item } from './item/item.model';
import { FormArray } from '@angular/forms';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class ItemService {

  constructor() {
  }

  public itemList = [
    {
      "id": 1,
      "name": "Ford",

    },
    {
      "id": 2,
      "name": "BMW",

    },
    {
      "id": 1,
      "name": "Fiad",

    }
  ]

  public setItems() {
    localStorage.setItem('itemList', JSON.stringify(this.itemList));
  }

  public getAll(){
    return JSON.parse(localStorage.getItem('itemList'));
  }  


  getItems(): Observable<Item[]> {
    return this.getAll()
      .pipe(map((items: Item[]) => {
        return items
      }));

  }

  getAllAsFormArray(): Observable<FormArray> {
    return this.getItems().pipe(map((items: Item[]) => {
      const fgroup = items.map(Item.asFormGroup);
      return new FormArray(fgroup);
    }));
  }

}
