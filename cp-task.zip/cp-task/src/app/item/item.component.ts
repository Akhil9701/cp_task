import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { ItemService } from '../item.service';
import { Item } from './item.model';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { MatSort, MatTableDataSource } from '@angular/material';

@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit, AfterViewInit {

  item: Item[] = [];
  form: FormGroup;
  @ViewChild(MatSort) sort: MatSort;
  public dataSource = new MatTableDataSource<Item[]>();
  displayedColumns = ['id', 'name']
  constructor(private itemService: ItemService, private formBuilder: FormBuilder) {
    this.setItems();
  }


  itemFormAsArray() {
    this.form = this.formBuilder.group({
      items: this.formBuilder.array([])
    });
    this.itemService.getAllAsFormArray().subscribe(res => {
      this.form.setControl('items', res);
      console.log(res);
    })
  }

  public doFilter = (value: string) => {
    this.dataSource.filter = value.trim().toLocaleLowerCase();

  }

  setItems() {
    this.itemService.setItems();
  }

  get items(): FormArray {
    return this.form.get('items') as FormArray;
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
  }

  ngOnInit(): void {
    this.itemFormAsArray();
  }

}
