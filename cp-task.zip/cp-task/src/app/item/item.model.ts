import { FormControl, FormGroup, Validators } from '@angular/forms';

export class Item {
    id: number;
    name: string;

    static asFormGroup(item: Item): FormGroup {
        const fg = new FormGroup({
            id: new FormControl(item.id, Validators.required),
            name: new FormControl(item.name, Validators.required)
        });
        return fg;
    }
}
